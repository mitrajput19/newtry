def hello():
  print("Hello")